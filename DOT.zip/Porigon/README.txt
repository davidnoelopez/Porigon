*********     DOT     *********

+++++++++ Primer Avance  +++++++++

Creacion de personaje:
		El personaje es un punto que se mueve con el cursor del raton.
		Puede disparar balas en todas direcciones con las teclas "A", "W", "D", "S".
		Y de ser necesario puede disparar una explosion que destruira todo a su paso con la barra espaciadora.
		
+++++++++++++++++++++++++++++++++++