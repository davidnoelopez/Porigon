*********     DOT     *********

+++++++++ Primer Avance  +++++++++

Creación de personaje:
		El personaje es un punto que se mueve con el cursor del raton.
		Puede disparar balas en todas direcciones con las teclas "A", "W", "D", "S".
		Y de ser necesario puede disparar una explosion que destruirá todo a su paso con la barra espaciadora.
		
+++++++++++++++++++++++++++++++++++

+++++++++ Segundo Avance  +++++++++

Enemigos:
		En esta iteración del proyecto. Se hizo la inclusión de los enemigos triangulares, estos siguen al punto para atacarlo y al momento de colisionar con el punto, el punto se vuelve de color rojo. Para protegerse, el punto puede disparar a los triangulos y estos seran aniquilados al momento de colisionar con alguna bala.
		
+++++++++++++++++++++++++++++++++++