//
//  Bala.cpp
//  Porigon
//
//  Created by Dave on 10/15/13.
//  Copyright (c) 2013 Dave. All rights reserved.
//

#include "Bala.h"

//
//  Bala.cpp
//  Porigon
//
//  Created by Dave on 10/14/13.
//  Copyright (c) 2013 Dave. All rights reserved.
//



Bala::Bala ()
{
    
}

Bala::Bala ( float posx, float posy, int dir )
{
    x = posx;
    y = posy;
    direccion = dir;
}